#include <iostream>
#include <stdio.h>
using namespace std;

int main (void){
	for ( int i = 0; i <= 3000; i = i+3){
		printf ("%d\n", i);
	}
}
